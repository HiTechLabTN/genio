# Comment récupérer et pousser ces changements

Je n'ai pas d'accès en écriture à `HiTechLabTN/genio` (pas de token, pas de
connecteur GitHub disponible dans cet environnement) — je ne peux donc pas
pousser directement. Tout le travail est prêt, testé et committé localement
sur une branche `feat/brand-assets-fluid-ui`, livré ici sous deux formes.

## Option A — le bundle Git (recommandé, garde tout l'historique des commits)

```bash
# Dans ton clone local de HiTechLabTN/genio :
git fetch /chemin/vers/genio-brand-assets-fluid-ui.bundle feat/brand-assets-fluid-ui:feat/brand-assets-fluid-ui
git checkout feat/brand-assets-fluid-ui
git push origin feat/brand-assets-fluid-ui
# puis ouvre une Pull Request vers main sur GitHub, ou merge directement :
git checkout main
git merge feat/brand-assets-fluid-ui
git push origin main
```

Le bundle contient `main` (tel qu'il était au moment du clone, commit
`731ec98`) et la branche `feat/brand-assets-fluid-ui` avec 4 commits dessus.
Si `main` a évolué depuis côté GitHub, fais plutôt un rebase avant de
pousser : `git rebase origin/main`.

## Option B — les patchs (si tu préfères relire/appliquer commit par commit)

4 fichiers `.patch` numérotés dans `patches/`, à appliquer dans l'ordre :

```bash
git am patches/0001-*.patch patches/0002-*.patch patches/0003-*.patch patches/0004-*.patch
```

## Ce que contiennent les 4 commits

1. **`feat(brand)`** — favicon, icônes PWA, icônes Electron intégrées aux
   bons chemins (`genio_client/public/`), manifest créé, `index.html`
   mis à jour. Build vérifié.
2. **`fix(gitignore)`** — le `.gitignore` racine excluait silencieusement
   tous les `.png` du repo (règle "média volumineux") ; ajout d'exceptions
   ciblées pour les assets de marque. **Sans ce commit, les icônes du
   commit 1 ne seraient jamais arrivées sur GitHub malgré un commit
   "réussi" en apparence** — à garder en tête si tu ajoutes d'autres PNG
   de marque plus tard, la même règle s'applique.
3. **`docs(branding)`** — bannière README, logo lockup, social preview
   GitHub + `docs/BRANDING.md` qui documente comment tout régénérer.
4. **`feat(chronos-portal)`** — le vrai visuel de la mascotte remplace
   l'avatar dessiné en CSS, animations `framer-motion` (flottement,
   pulsation liée au vrai statut de l'agent, morph fluide minimisé ↔
   étendu). Deuxième occurrence du même piège `.gitignore`, corrigée dans
   le même commit.

## Action manuelle restante après le push (pas automatisable par un commit)

- **Social preview GitHub** : Settings → General → Social preview → upload
  `docs/github-social-preview.png`.
  https://github.com/HiTechLabTN/genio/settings
- **Icônes Android/iOS natives** : rien à faire manuellement — elles sont
  régénérées automatiquement en CI (`npx capacitor-assets generate`,
  câblé dans `.github/workflows/release-binaries.yml`, testé en conditions
  réelles pendant cette session : 110 fichiers générés correctement).
- **`.icns` macOS pour Electron** : toujours en attente (limite déjà
  signalée dans l'audit round 2/3 — nécessite soit un job CI macOS avec
  `electron-icon-builder`, soit une génération manuelle sur Mac).

## Ce qui a été vérifié pendant cette session (pas juste écrit)

- `npm run build` (tsc strict + vite) passe après chaque commit.
- Tous les chemins d'icônes référencés dans `index.html`/manifest existent
  réellement dans `dist/` après build (croisement fichier par fichier).
- `cap add android` + `npx capacitor-assets generate --android` exécutés
  réellement contre les sources fournies → 110 fichiers mipmap/adaptive-icon
  générés avec succès.
- Le piège `.gitignore` a été détecté par vérification (`git ls-files`),
  pas supposé — deux fois, sur deux chemins différents.
